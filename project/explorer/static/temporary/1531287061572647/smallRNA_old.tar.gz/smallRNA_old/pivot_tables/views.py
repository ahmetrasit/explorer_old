from django.shortcuts import render, render_to_response
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.http import JsonResponse

from basics.models import Job
from basics.forms import UploadFileForm

import os
import time
import subprocess
import re
import json

# Create your views here.
@login_required
def listData(request):
	fileList = []
	dir = 'static/upload/'
	activeDirectories = [file for file in os.listdir(dir) if file[0] != '.']
	patwhaysGeneList = ''
	with open('static/library/patwhaysGeneList.json') as f:
		patwhaysGeneList = ''.join(f.readlines())
	for active in activeDirectories:
		currDir = dir + active + '/csv'
		files = [file for file in os.listdir(currDir) if file[0] != '.']
		for file in files:
			fileList.append(active + '/' + file)
	return render(request, 'createPivot.html', {'user':request.user, 'files':fileList, 'patwhaysGeneList':patwhaysGeneList})

@csrf_exempt
def receiveRequest(request):
	#print('yep')
	#print('python3 ./static/scripts/userPivot.py ' + request.user.username + ' "'  + request.POST['pivot'].replace('"', '\'') + '" "'  + request.POST['filter'] + '" ')
	subprocess.Popen('python3 ./static/scripts/userPivot.py ' + request.user.username + ' ' + request.user.email +' "'  + request.POST['pivot'].replace('"', '\'') + '" "'  + request.POST['filter'].replace('"', '\'') + '" ', shell=True)

	print('subprocess started')

@login_required
def getFile(request, prefix):
	htmlFile= 'upload/' + str(request.user) + '/userdata/' + prefix + '.html'
	fragments = {}
	for ci, curr in enumerate(['style', 'html', 'js']):
		with open('static/upload/' + str(request.user) + '/userdata/' + prefix + '.' + curr) as f:
			fragments[curr] = '\n'.join(f.readlines())

	csvFile = 'upload/' + str(request.user) + '/userdata/' + prefix + '.csv'
	return render(request, 'servePivotFile.html', {'user':request.user, 'htmlFile':htmlFile, 'csvFile':csvFile, 'style':fragments['style'], 'html':fragments['html'], 'js':fragments['js']})
