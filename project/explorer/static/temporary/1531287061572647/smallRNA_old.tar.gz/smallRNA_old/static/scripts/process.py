import sys
import os
import notify
import subprocess
import time
import re
from collections import Counter

start = int(time.time())
_, username, email, job_id, type, session, parameters = sys.argv
print(sys.argv)
os.chdir('./static/upload/'+username+'/'+job_id)
files = []




if type == 'multiplex':
	files = [file for file in os.listdir('./') if file[0] != '.']
	barcodes, samples, details, adapter = parameters.split("|")
	barcodes = [barcode.strip() for barcode in barcodes.split(",")]
	if adapter.strip() == '':
		adapter = '-a AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC '
	else:
		adapter = '-a AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC ' + '-a ' + re.sub(r'[^ATGC]', '', adapter)
	barcode2sample = {}
	command = "cat " + ' '.join(files) + ' > ' + session + ".fastq.gz ; cutadapt --cores=12 " + adapter + " -e 0.1 -O 5 -m 14 " + session + ".fastq.gz |  paste - - - - | awk -F\\t '{print $1 \"|\"$2}' > " + session + ".temp"
	#print(command)
	currCommand = subprocess.Popen(command, shell=True)
	currCommand.wait()


	samples = samples.split(",")
	details = details.split(",")
	for i in range(len(barcodes)):
		barcode2sample[barcodes[i]] = re.sub(r'\W+', '_', samples[i].strip())
	barcode2seq = {barcode:[] for barcode in barcodes}
	all_barcode_sequences = []
	with open(session + ".temp") as f:
		for line in f.readlines():
			definition, seq = line.strip().split("|")
			barcode = definition.split(' ')[1].split(":")[3]
			all_barcode_sequences.append(barcode)
			if barcode in barcodes:
				barcode2seq[barcode].append(seq)
			else:
				pass
	for barcode in barcode2seq:
		print(barcode)
		print(len(barcode2seq[barcode]))
		curr = barcode2seq[barcode]
		outfile = barcode2sample[barcode]+'.txt'
		with open(outfile, 'w') as f:
			f.write('\n'.join([c for c in curr]))
		no_processors = str(12/len(barcode2seq.keys()) + 1)

		command = "awk '{if(length($0)<41)count[$0]++}END{for(word in count)print \">\"word\":\"count[word]\"\\n\"word}' " + outfile + " > " + outfile + ".raw_counts.fa ; bowtie2 -f -p "+no_processors+" -k 100 -x /Users/ahmetrasit/tools/cel/WBcel235struc -U " + outfile + ".raw_counts.fa   > " + outfile + ".struc; touch " + outfile + ".finished"
		subprocess.Popen(command, shell=True)
	print('all barcodes in the data:')
	count = 0
	for barcode, count in Counter(all_barcode_sequences).most_common():
		count += 1
		if count < 21:
			print(barcode + "\t" + str(count))

	files = [barcode2sample[barcode]+'.txt' for barcode in barcode2sample]
	cont = True
	finished = []
	while cont:
		count = 0
		for file in files:
			if file in finished:
				count +=1
			elif os.path.isfile('./' + file + '.finished'):
				finished.append(file)
				count +=1
				command = " awk '{if($2 == '4'){split($1, temp, \":\");print \">\"$1\"\\n\"temp[1]}}' " + file + ".struc | bowtie2 -f -p "+no_processors+" -k 100 -x /Users/ahmetrasit/tools/cel/WS250DetailedAnnotationLocation -  | grep -v '@' > " + file + ".cleaned.txt ; touch " + file + ".ready"
				subprocess.Popen(command, shell=True)
		time.sleep(5)
		#print('check them all')
		cont = False
		if count < len(files):
			cont = True


elif type=='plain':
	files = [file for file in os.listdir('./') if file[0] != '.']
	barcodes, samples, details, adapter = parameters.split("|")
	if adapter.strip() == '':
		adapter = '-a AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC'
	else:
		adapter = '-a AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC' + '-a ' + re.sub(r'[^ATGC]', '', adapter)

	#print(adapter)
	for file in files:
		print("Trimming adaptors and counting sequences in " + file)
		no_processors = str(12/len(files) + 1)
		#print(no_processors)
		#command = "cutadapt " + adapter + " -e 0.1 -O 5 -m 15 " + file + " |  paste - - - - | awk -F\\t  '{print $2}'   |  awk '{if(length($0)<41)count[$0]++}END{for(word in count)print \">\"word\":\"count[word]\"\\n\"word}' > " + file + ".raw_counts.fa ; bowtie2 -f -p "+no_processors+" -a -x /Users/ahmetrasit/tools/cel/WBcel235struc -U " + file + ".raw_counts.fa   > " + file + ".struc; touch " + file + ".finished"
		command = "cutadapt --cores=12 " + adapter + " -e 0.1 -O 5 -m 14 " + file + " |  awk '((NR-2)%4==0){count[$0]++}END{for(word in count)print \">\"word\":\"count[word]\"\\n\"word}' > " + file + ".raw_counts.fa ; bowtie2 -f -p "+no_processors+" -k 100 -x /Users/ahmetrasit/tools/cel/WBcel235struc -U " + file + ".raw_counts.fa   > " + file + ".struc; touch " + file + ".finished"
		#print(command)
		subprocess.Popen(command, shell=True)
	cont = True
	finished = []
	while cont:
		count = 0
		for file in files:
			if file in finished:
				count +=1
			elif os.path.isfile('./' + file + '.finished'):
				finished.append(file)
				count +=1
				#print ('bowtie2 for non-struc starts for: ' + file)

				#pseudogenes are missing in the following bowtie index
				#command = " awk '{if($2 == '4'){split($1, temp, \":\");print \">\"$1\"\\n\"temp[1]}}' " + file + ".struc | bowtie2 -f -p "+no_processors+" -a -x /Users/ahmetrasit/tools/cel/WBcel235AnnotBetter -  | grep -v '@' > " + file + ".cleaned.txt ; touch " + file + ".ready"
				command = " awk '{if($2 == '4'){split($1, temp, \":\");print \">\"$1\"\\n\"temp[1]}}' " + file + ".struc | bowtie2 -f -p "+no_processors+" -k 100 -x /Users/ahmetrasit/tools/cel/WS250DetailedAnnotationLocation -  | grep -v '@' > " + file + ".cleaned.txt ; touch " + file + ".ready"
				subprocess.Popen(command, shell=True)
		time.sleep(5)
		#print('check them all')
		cont = False
		if count < len(files):
			cont = True

elif type=='row_counts':
	files = [file for file in os.listdir('./') if file[0] != '.']


	#print(adapter)
	for file in files:
		print("Trimming adaptors and counting sequences in " + file)
		no_processors = str(12/len(files) + 1)
		#print(no_processors)
		#command = "cutadapt " + adapter + " -e 0.1 -O 5 -m 15 " + file + " |  paste - - - - | awk -F\\t  '{print $2}'   |  awk '{if(length($0)<41)count[$0]++}END{for(word in count)print \">\"word\":\"count[word]\"\\n\"word}' > " + file + ".raw_counts.fa ; bowtie2 -f -p "+no_processors+" -a -x /Users/ahmetrasit/tools/cel/WBcel235struc -U " + file + ".raw_counts.fa   > " + file + ".struc; touch " + file + ".finished"
		command = "touch " + file + ".finished"
		#print(command)
		subprocess.Popen(command, shell=True)
	cont = True
	finished = []
	while cont:
		count = 0
		for file in files:
			if file in finished:
				count +=1
			elif os.path.isfile('./' + file + '.finished'):
				finished.append(file)
				count +=1
				#print ('bowtie2 for non-struc starts for: ' + file)

				#pseudogenes are missing in the following bowtie index
				#command = " awk '{if($2 == '4'){split($1, temp, \":\");print \">\"$1\"\\n\"temp[1]}}' " + file + ".struc | bowtie2 -f -p "+no_processors+" -a -x /Users/ahmetrasit/tools/cel/WBcel235AnnotBetter -  | grep -v '@' > " + file + ".cleaned.txt ; touch " + file + ".ready"
				command = "bowtie2 -f -p "+no_processors+" -k 100 -x /Users/ahmetrasit/tools/cel/WS250DetailedAnnotationLocation -U " + file + "  | grep -v '@' > " + file + ".cleaned.txt ; touch " + file + ".ready"
				subprocess.Popen(command, shell=True)
		time.sleep(5)
		#print('check them all')
		cont = False
		if count < len(files):
			cont = True






#print('check the list of files regarding the type of analysis')
#print(type)
#print (files)

print('all bowties submitted')

notFinished = {file:1 for file in files}
active = {}
started = {}
while len(notFinished) > 0:
	curr_files = notFinished.keys()
	for file in curr_files:
		if os.path.isfile('./' + file + '.ready'):
			if len(active) > 1:
				pass
			else:
				active[file] = 1
				del notFinished[file]
				started[file] = 1
				subprocess.Popen('python3 ../../../scripts/pivot.py ' + os.path.abspath('./' + file + '.cleaned.txt'), shell=True)
				print('# of active process(es):\t' + str(len(active)) )
	for file in started.keys():
		if os.path.isfile('./' + file + '.cleaned.txt.csv'):
			if file in active:
				del active[file]
	time.sleep(30)


waitingParse = {file:1 for file in files}
while len(waitingParse) > 0:
	curr_files = waitingParse.keys()
	for file in curr_files:
		if os.path.isfile('./' + file + '.cleaned.txt.csv'):
			print(str(len(waitingParse)-1) + ' analysis still running')
			del waitingParse[file]
	time.sleep(30)

time.sleep(120)

subprocess.Popen('touch job_finished', shell=True)
msg = 'It took ' + str(int(time.time()) - start) + ' seconds for ' + str(len(files)) + ' files. Job Id is ' + str(job_id) + '. '

subprocess.Popen('touch smallRNAsession.'+session, shell=True)

notify.notification(email, session, msg)
notify.notification('Ahmet.Ozturk@umassmed.edu', session, username + ' created a job request. ' + msg)
print('notification sent to ahmetrasit@gmail.com')


def filter():
	pass


def calculateBySpecies():
	files = [file for file in os.listdir('./') if '.cleaned.txt' in  file]
	for file in files:
		species = countSpecies(file)

def countSpecies(file, annot2type):
	seq2annot = {}
	seq2count = {}
	notfound = {}
	species = {}

	with open(file) as f:
		for line in f.readlines():
			fields = line.split('\t')
			seq = fields[0].split(':')[0]
			curr_species = str(len(seq)) + seq[0]
			try:
				species[curr_species].append(fields[:5])
			except:
				species[curr_species] = [fields[:5]]

	for curr in species:
		report(species[curr])


	for line in lines:
		fields = line.split('\t')
		seq = fields[0].split(':')[0]
		curr_species = str(len(seq)) + seq[0]
		count = fields[0].split(':')[1]
		seq2count[seq] = count
		code = fields[1]
		annot = fields[2]
		cigar = fields[5]

		if code == '4':
			if seq in seq2annot:
				seq2annot[seq].add(annot)
			else:
				seq2annot[seq] = set([annot])
		else:
			notfound[seq] = '-'
