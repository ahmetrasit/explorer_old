import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText



def notification(email, session, details):

	msg = MIMEMultipart()
	msg['From'] = "smallrnapipeline@gmail.com"
	msg['To'] = email
	msg['Subject'] = session +  " is processed."

	body = "You can see your results when you login. "
	body += details
	msg.attach(MIMEText(body, 'plain'))

	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login("smallrnapipeline@gmail.com", "small1rna2pipeline")
	text = msg.as_string()
	server.sendmail("smallrnapipeline@gmail.com", email, text)
	server.quit()
