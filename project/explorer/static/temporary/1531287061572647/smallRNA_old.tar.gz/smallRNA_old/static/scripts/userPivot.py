import pandas as pd
import numpy as np
import notify
import time
import json
import sys
import ast
import re
import os





_, username, email, pivotParameters, filterParameters = sys.argv
#print(pivotParameters)
os.chdir('./static/upload/'+username+'/csv')

def simplify(x):
        if '3_utr' in x:
            return '3_utr'
        elif '5_utr' in x:
            return '5_utr'
        elif 'exon' in x:
            return 'CDS'
        elif 'intron' in x:
            return 'intron'
        else:
            return 'other'

def getStrand(x):
    if x == 4:
        return 'None'
    if x == 0 :
        return 'Sense'
    if x == 256 :
        return 'Sense'
    if x == 16 :
        return 'Anti-Sense'
    if x == 272 :
        return 'Anti-Sense'
    return 'Other'


def createPivotTableHMTL(merged, indexList, columnList, filterParameters):
    mergedClassesText, th = createHeader(merged, indexList, columnList, filterParameters)
    tbody = createCells(merged, indexList, columnList, mergedClassesText)
    style = colMdCustomize(len(mergedClassesText[0]) + len(indexList))
    js = getJavaScript()
    return [style, '<div class="container">\n' + th + '\n' + tbody + '\n</div>', js]


def createHeader(merged, indexList, columnList, filterParameters):
    noc = len(merged.columns)
    nol = len(merged.columns.levels)
    extendedLevels = ['file'] + columnList
    classes = [[] for _ in range(nol)]
    mergedClassesText = []
    header = ''
    for i in range(nol):
        mergedClasses = [[] for _ in range(len(merged.columns.labels[0]))]
        currLabels = merged.columns.labels[i]
        currLevels = [str(curr).split(".")[0] for curr in merged.columns.levels[i]]
        for ci, curr in enumerate(currLabels):
            classes[i].append(currLevels[curr])
        lenClasses = sum([1 for i in range(len(classes)) if len(classes[i])>0])
        for k in range(lenClasses):
            for m in range(len(classes[0])):
                mergedClasses[m].append(extendedLevels[k] + '_' + classes[k][m])
        #print(mergedClasses)
        mergedClassesText.append([' '.join(curr) for curr in mergedClasses])
        currHtml = []
        for n in range(len(classes[i])):
            #print(mergedClassesText[0][n])
            currHtml.append('\t<div  style="border:.5px solid black;" class="' + mergedClassesText[i][n] + ' col-md-$$$" onclick="highlightSelected(this)"><label>' + (classes[i][n] or '-') + '</label></div>\n')
        order = []
        count = []
        for ci, curr in enumerate(currHtml):
            if len(order) > 0 and curr == order[-1]:
                count[-1] += 1
            else:
                order.append(curr)
                count.append(1)
        finalHtml = []
        #extending the first index columns to col-md-2
        for il in range(len(indexList)):
            count[il]+=1
        for ind in range(len(order)):
            finalHtml.append(order[ind].replace('$$$', str(count[ind])))
        header += ''+''.join(['<div class="col-md-'+str(len(merged.columns.labels[0]))+'">\n']+finalHtml+['</div>']) + '\n'
    header = '<div class="col-md-' + str(noc) + '">' + json.dumps(filterParameters) + "</div>" + header
    return[mergedClassesText, header]


def createCells(merged, indexList, columnList, mergedClassesText):
    noc = len(merged.columns)
    nol = len(merged.columns.levels)
    lil = len(indexList)
    html = ''
    for row in merged.itertuples():
        rowClasses = ' '.join([indexList[ci] + '_' + re.sub(r'\W+','_', curr) for ci, curr in enumerate(row[1:lil+1])])
        rowDiv = []
        for curr in row[1:lil+1]:
            rowDiv.append('\t<div class="col-md-2 '  + rowClasses +'" onclick="highlightSelected(this)"><label>' + (curr) + '</label></div>')
        for ci, curr in enumerate(row[lil+1:]):
            currTemp = str(curr)
            currStr = currTemp.split('.')[0]
            emptyClass = ''
            if len(currTemp)<1:
                emptyClass = ' empty '
            if len(currTemp.split('.'))>1:
                currStr += '.' + currTemp.split('.')[1][:2]

            rowDiv.append('\t<div class="col-md-1 ' + mergedClassesText[nol-1][ci+lil] + ' ' + rowClasses + emptyClass +'">' + (currStr or '0') + '</div>')
        html += '\n'.join(['<div class="col-md-'+str(len(merged.columns.labels[0])) + ' ' + rowClasses + '">'] + rowDiv + ['</div>'])
    return html


def colMdCustomize(n):
    firstPart = ', '.join(['.col-md-' + str(i) for i in range(1, n+1)]) + ' {border:.5px solid lightgray;position:relative;min-height:1px;padding-left:1px;padding-right: 1px;text-align:center}'
    secondPart = '@media (min-width: 1px) {' + ', '.join(['.col-md-' + str(i) for i in range(1, n+1)]) + '{float: left;}'
    thirdPart = '\n'.join(['.col-md-' + str(i) + ' {width:' + str(round(i*(100/n), 5)) + '%;}' for i in range(1, n+1)])

    return '\n'.join(['<style>', firstPart, secondPart, thirdPart, '.container {min-width:' + str(n*65) + 'px}', '</style>'])


def getJavaScript():
    highlightSelected = '''
    function highlightSelected(curr){
        if(curr.className.includes('selected')){
            d3.selectAll('.' + curr.className).style('background-color', 'white')
            d3.selectAll('.' + curr.className).attr('class', curr.className.replace(' selected ', ''))
            fields = curr.className.split(' ')
            for(var fi=0;fi<fields.length;fi++){
                if(typeof fields[fi] == 'undefined'){
                    fields.splice(fi,1)
                }
                if( fields[fi].includes("col-md-") ){
                    fields.splice(fi,1)
                }
            }
            curr = d3.selectAll('.'+fields[0])
            if(fields.length>1){
                for(var i=1;i<fields.length; i++){
                    if(fields[i].length>0){
                        curr = curr.filter('.'+fields[i])
                    }
                }
            }
            curr.style('background-color', 'white')
            curr.attr('class',  function(d,i){return this.className.replace(' selected ', '')})
        }else{
            d3.selectAll('.' + curr.className).style('background-color', '#B0CBDB')
            fields = curr.className.split(' ')
            for(var fi=0;fi<fields.length;fi++){
                if(typeof fields[fi] == 'undefined'){
                    fields.splice(fi,1)
                }
                if( fields[fi].includes("col-md-") ){
                    fields.splice(fi,1)
                }
            }

            curr = d3.selectAll('.'+fields[0])
            if(fields.length>1){
                for(var i=1;i<fields.length; i++){
                    curr = curr.filter('.'+fields[i])
                }
            }
            curr.style('background-color', '#B0CBDB')
            curr.attr('class',  function(d,i){return this.className + ' selected '})
        }
    }

    '''

    return '\n'.join(['<script>' + "d3.selectAll('.empty').style('color', 'lightgray')" + highlightSelected + '</script>'])




def filterData(parentDir, filename, filterDict, indexList, columnList, pivotFunction, geneList):
    data = pd.read_csv(parentDir + filename).fillna('-')
    #print(len(data))
    if len(geneList)>0:
        data = data[(data['alias'].isin(geneList)) | (data['gene'].isin(geneList)) ]
    #print(len(data))

    filtered = data[(data['len']>=int(filterDict['lenMin_'])) & (data['len']<=int(filterDict['lenMax_'])) & (data['ppm']>=int(filterDict['ppmMin_'])) ]
    filtered['base'] = filtered['seq'].map(lambda x:x[0])
    filtered['strand'] = filtered['code'].map(getStrand)
    if filterDict['base_'] != 'All':
        #print('base_')
        filtered = filtered[filtered['base'] == filterDict['base_']]
    if filterDict['type_'] != 'All':
        #print('type_')
        filtered = filtered[filtered['gene_type'] == filterDict['type_']]
    if filterDict['strand_'] != 'All':
        #print('strand_')
        filtered = filtered[filtered['strand'] == filterDict['strand_']]
    if re.search("\d", filterDict['ppmMax_']):
        #print('ppmMax_')
        filtered = filtered[filtered['ppm']<=int(filterDict['ppmMax_'])]

    filtered['element'] = filtered['position'].map(simplify)
    if 'element' in columnList or 'element' in indexList:
        pass
    else:
        filtered = filtered[(filtered['element']=='CDS') | (filtered['element']=='5_utr') | (filtered['element']=='3_utr')]
    #print(len(filtered))
    pivot = createPivot(filtered, indexList, columnList, pivotFunction, filterDict['postFilter_'])
    #print(len(pivot))
    #print(pivot)
    return pivot


def createPivot(data, indexList, columnList, pivotFunction, postFilter):
    if columnList[0] == 'tempColumn':
        data['tempColumn'] = 'ppm'
    if len(indexList) > 0:
        print(indexList)
        if '20bp' in indexList:
            data = data[data['len']>=20]
            data['20bp'] = data['seq'].map(lambda x: x[:20])
        pivot = pd.pivot_table(data, index=indexList, columns = columnList, values=['ppm'], aggfunc=(pivotFunction) ).fillna(0)
        pivot = pivot[(pivot>=int(postFilter)).any(axis=1)]
        return pivot
    else:
        print('not enough arguments for pivot table')
        return data

filterName2pivotName = {}
pivotParameters = ast.literal_eval(pivotParameters)
filterParameters = ast.literal_eval(filterParameters)


pivotParameter2columnName = {
'Gene':'alias',
'Base': 'base',
'Length':'len',
'Position':'element',
'Sequence':'seq',
'Species':'species',
'Type':'gene_type',
'Strand':'strand',
'First20':'20bp'
}
indexList = []
for curr in ['ind1', 'ind2', 'ind3', 'ind4']:
    if '---' not in pivotParameters[curr]:
        indexList.append(pivotParameter2columnName[pivotParameters[curr]])

columnList = []
for curr in ['col1', 'col2', 'col3', 'col4']:
    if '---' not in pivotParameters[curr]:
        columnList.append(pivotParameter2columnName[pivotParameters[curr]])

if len(columnList) < 1:
    columnList = ['tempColumn']
    print(columnList)

geneList = [gene for gene in re.split(r"[^a-zA-Z0-9-.]", pivotParameters['filterGeneList']) if gene != '']
#print(len(geneList))
merged = pd.DataFrame()
for fi, file in enumerate(sorted(filterParameters.keys())):
    print(file)
    filename = file.split("/")[1] + '.cleaned.txt.csv'
    parentDir = '../../' + file.split("/")[0] + '/' + 'csv/'
    currFilterParamDict = filterParameters[file]
    filtered = filterData(parentDir, filename, currFilterParamDict, indexList, columnList, pivotParameters['function'], geneList).reset_index()
    filtered.rename(columns={'ppm':filename.split('.')[0]}, inplace=True)
    if fi == 0:
        merged = filtered
    else:
        merged = pd.merge(merged, filtered, how='outer', on=indexList)
#print(merged)
currTime = int(time.time())
merged = merged.replace({0: ''}).fillna('')
pd.set_option('display.max_colwidth', -1)
userSessionName = re.sub(r'\W+', '_', pivotParameters['userSessionName'].strip())
prefix = ''
if len(userSessionName) < 1:
    prefix =  str(len(filterParameters.keys())) + '_files.' + '_'.join(indexList) + '_and_' + '_'.join(columnList) + '.' + time.strftime("%Y_%m_%d", time.localtime())+ '.' + str(int(time.time()))[-5:]
else:
    prefix =  userSessionName + '.' + time.strftime("%Y_%m_%d", time.localtime())+ '.' + str(int(time.time()))[-5:]
merged.to_html('../userdata/' + prefix + '.html')

style, html, js = createPivotTableHMTL(merged, indexList, columnList, filterParameters)
with open('../userdata/' + prefix + '.style', 'w') as f:
    f.write(style)
with open('../userdata/' + prefix + '.html', 'w') as f:
    f.write(html)
with open('../userdata/' + prefix + '.js', 'w') as f:
    f.write(js)


merged.to_csv('../userdata/' + prefix + '.csv')

msg = 'Your pivot table for the following ' + str(len(filterParameters.keys())) + ' files are ready:' + ', '.join([file for file in filterParameters.keys()]) + '. \n<br>'
msg += ' You can reach your files through this link: http://146.189.165.89:8080/pivot/getFile/' + prefix

notify.notification(email, prefix, msg)
if email != "ahmetrasit@gmail.com":
    notify.notification('Ahmet.Ozturk@umassmed.edu', prefix, email + ' asked for a pivot table. ' + msg)
print('HTML file is ready')
