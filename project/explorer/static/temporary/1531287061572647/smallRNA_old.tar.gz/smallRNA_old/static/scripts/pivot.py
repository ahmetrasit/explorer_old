import pandas as pd
import numpy as np
import re
import gc


import sys
import os
import time
import json


import warnings
warnings.filterwarnings('ignore')


#python3 manage.py runserver 0.0.0.0:8080

def categorize(num):
    if num >= 25:
        return 25
    elif num >= 20:
        return 20
    elif num >= 15:
        return 15
    elif num >= 10:
        return 10
    else:
        return int(num)


def repeatFilter(seq):
    #if re.match('A{8,}|T{8,}|G{8,}|C{8,}|N{1,}', seq):
    if 'N' in seq:
        return 'yes'
    elif 'AAAAAAAAAAAA' in seq:
        return 'yes'
    elif 'TTTTTTTTTTTT' in seq:
        return 'yes'
    elif 'GGGGGGGGGGGG' in seq:
        return 'yes'
    elif 'CCCCCCCCCCCC' in seq:
        return 'yes'
    else:
        return 'no'

def getType(x):
    if ":" in x:
        return x.split(":")[1]
    else:
        return "*"



def getDetailedAnnotationInformation():
    gene2information = {}
    gene2exons = {}
    gene2introns = {}
    gene2borders = {}
    gene2five = {}
    gene2three = {}

    for curr in  ['gene2exons', 'gene2introns', 'gene2borders', 'gene2five', 'gene2three', 'gene2alias'  ]:
        with open('../../../library/' + curr + '.json') as f:
            gene2information[curr] = json.load(f)

    return [gene2information[curr] for curr in ['gene2exons', 'gene2introns', 'gene2borders', 'gene2five', 'gene2three', 'gene2alias'  ] ]



def findPosition(row):
	offset = 30
	categories = []
	fields = row.split("|")
	start = int(float(fields[0]))
	end = int(float(fields[1]))
	gene = fields[2]
	seq_type = fields[3]
	if gene == "*":
		pass
	elif seq_type == 'exon_boundary':
		categories = ['exon_boundary|0']
	else:
		fives = 0
		threes = 0
		global gene2borders
		global gene2exons
		global gene2introns
		global gene2five
		global gene2three
		gene_start = gene2borders[gene]['start']
		gene_end = gene2borders[gene]['end']
		len_gene = gene_end-gene_start
		exons = getCategory(start, end, gene2exons[gene])
		if seq_type == 'exon':
			if exons > 0:
				categories.append('exon|' + str(exons))
		else:
			introns = getCategory(start, end, gene2introns[gene])
			if gene in gene2five:
				fives = getCategory(start, end, gene2five[gene])
			if gene in gene2three:
				threes = getCategory(start, end, gene2three[gene])

			if fives > 0:
				categories.append('5_utr|' + str(fives))
			if exons > 0:
				categories.append('exon|' + str(exons))
			if introns > 0:
				categories.append('intron|' + str(introns))
			if threes > 0:
				categories.append('3_utr|' + str(threes))
			if start <=offset-1:
					categories.append('5_utr|1')
			if end >= len_gene - offset + 1:
					categories.append('3_utr|1')

		if len(categories) < 1:
			categories = ['other|0']

	return ';'.join(sorted(list(set(categories))))



def getCategory(start, end, category):
    for index, curr in enumerate(category):
        s = int(curr[0])
        e = int(curr[1])
        midpoint = start + int((end-start)/2)

        if start < e and start >= s:
            return index+1
        elif end < e and end >= s:
            return index+1
        elif midpoint < e and midpoint >= s:
            return index+1

    return 0



def partitionTemp(curr):
    return '|'.join(sorted( list( set([ field.split("|")[0] for field in curr.split(";") ]) )) )



def parseData(file):
	start = int(time.time())
	reads = pd.read_table(file, header=None, usecols = [0,1,2,3], names=['read', 'code', 'annot', 'start'])
	reads['seq'] = reads['read'].map(lambda x: x.split(":")[0])
	reads['count'] = reads['read'].map(lambda x: int(x.split(":")[1]))
	#data = data.drop(['repeat', 'read'], axis=1)
	total_reads_sum = reads[['seq', 'count']].drop_duplicates()['count'].sum()

	transcript = reads[reads['annot'].str.contains('transcript')]
	transcript['gene'] = transcript['annot'].str.split("|", 2).str.get(1)
	transcript['seq_gene'] = transcript['seq'] + "|" + transcript['gene']

	unspliced = reads[~reads['annot'].str.contains('transcript')]
	unspliced['gene'] = unspliced['annot'].str.split("|", 2).str.get(0)
	unspliced['seq_gene'] = unspliced['seq'] + "|" + unspliced['gene']

	reads = None
	del reads

	merged = pd.merge(transcript.drop_duplicates(), unspliced.drop_duplicates(), on='seq_gene', how='outer')
	merged.loc[(merged['seq_x'].notnull()) & (merged['seq_y'].notnull()), 'seq_type'] = 'exon'
	merged.loc[(merged['seq_x'].notnull()) & (merged['seq_y'].isnull()), 'seq_type'] = 'exon_boundary'
	merged.loc[(merged['seq_x'].isnull()) & (merged['seq_y'].notnull()), 'seq_type'] = 'other'

	transcript = None
	unspliced = None
	del transcript
	del unspliced
	gc.collect()

	exons = merged[merged['seq_type'] == 'exon']
	exons[['seq', 'code', 'annotation', 'start', 'count', 'gene', 'seq_type']] = exons[['seq_y', 'code_y', 'annot_y', 'start_y', 'count_y', 'gene_y', 'seq_type']]
	exons['gene_type'] = exons['annotation'].str.split("|").str.get(2)
	exons['alias'] = exons['annotation'].str.split("|").str.get(1)
	exons = exons[['seq', 'code', 'start', 'count', 'gene', 'seq_type', 'gene_type', 'alias']]

	exon_boundary = merged[merged['seq_type'] == 'exon_boundary']
	exon_boundary[['seq', 'code', 'annotation', 'start', 'count', 'gene', 'seq_type']] = exon_boundary[['seq_x', 'code_x', 'annot_x', 'start_x', 'count_x', 'gene_x', 'seq_type']]
	exon_boundary['gene_type'] = exon_boundary['annotation'].str.split("|").str.get(2)
	exon_boundary['alias'] = exon_boundary['annotation'].str.split("|").str.get(3)
	exon_boundary = exon_boundary[['seq', 'code', 'start', 'count', 'gene', 'seq_type', 'gene_type', 'alias']]

	other = merged[merged['seq_type'] == 'other']
	other[['seq', 'code', 'annotation', 'start', 'count', 'gene', 'seq_type']] = other[['seq_y', 'code_y', 'annot_y', 'start_y', 'count_y', 'gene_y', 'seq_type']]
	other['gene_type'] = other['annotation'].str.split("|").str.get(2)
	other['alias'] = other['annotation'].str.split("|").str.get(1)
	other = other[['seq', 'code', 'start', 'count', 'gene', 'seq_type', 'gene_type', 'alias']]

	data = exons.append(exon_boundary).append(other)

	exons = None
	exon_boundary = None
	other = None

	del exons
	del exon_boundary
	del other
	gc.collect()

	data['repeat'] = data['seq'].map(repeatFilter)
	data = data.drop(data[data['repeat'] =='yes'].index)

	data['species'] = data['seq'].map(lambda x: str(len(x)) + x[0])

	seq2count = data.groupby('seq').count()['gene'].to_dict()
	data['mult'] = data['seq'].map(lambda x: seq2count[x])
	data['shared_count'] = data['count'] / data['mult']

	#now counting
	total_read_count = data['shared_count'].sum()
	data['ppm'] = data['shared_count'].map(lambda x: round(1000000.0 * x/total_read_count, 3))

	print("total read count before for "+file.split("/")[-1]+":\t" + str(total_reads_sum))

	data['len'] = data['seq'].map(lambda x: len(x))
	data['end'] = data['start'].map(int) + data['len'].map(int)
	data['end'] = data['end'].map(lambda x:x-1)

	data['location_temp'] = data['start'].map(str) + "|" + data['end'].map(str) + "|" + data['gene'] + "|" + data['seq_type']
	data['position_temp'] = data['location_temp'].map(findPosition)

	data['position'] = data['position_temp'].map(partitionTemp)

	curr = int(time.time()) - start
	data = data[['seq', 'code', 'start', 'count', 'gene', 'seq_type', 'gene_type', 'alias', 'species', 'shared_count', 'ppm', 'len', 'end', 'position_temp', 'position']]

	data.to_csv(file+'.csv')

	data['cat'] = data['ppm'].map(categorize)
	pd.pivot_table(data, index=['cat', 'len', 'species'], values=['ppm'] ,aggfunc=[np.sum, len]).to_json(file+'.json', orient='split')
	with open(file+'.sum', 'w') as f:
		f.write(str(total_read_count))

	curr = int(time.time()) - start
	print('it took ' + str(curr) + ' secs for ' + file)


file = sys.argv[1]

print('Processing bowtie2 output for ' + file)
gene2exons, gene2introns, gene2borders, gene2five, gene2three, gene2alias = getDetailedAnnotationInformation()
parseData(file)
