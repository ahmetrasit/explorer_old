#Adaptor trimming main function

from collections import Counter
import os
import re

adapter_sequence = 'AGATCGG'

def revComp(seq):
	rev = {'A':'T', 'T':'A', 'G':'C', 'C':'G', 'N':'N'}
	return ''.join([rev[s] for s in seq[::-1]])

def removeAdapter(file, minLen=16, maxLen=40):
	print file
	getReverse=False
	if re.search('_R2(_\d+)?\.fastq', file):
		getReverse = True
		print "R2 found: "+ file
		
	adapters = []
	smallRNAs = []
	found = 0
	notfound = 0
	sample = ''
	all = []
	nonfounds = []
	with open(file) as f:
		all = f.readlines()
	seqs = all[1::4]
	for seq in seqs:
		pos = re.search('(^\w{'+str(minLen)+','+str(maxLen)+'})AGAT?CGGAAGAG', seq)
		#adapters.append(pos)
		if pos:
			found += 1
			if getReverse:
				smallRNAs.append(revComp(pos.group(1)))
			else:
				smallRNAs.append(pos.group(1))
		else:
			pos = re.search('(^\w{'+str(minLen)+','+str(maxLen)+'})AGAT?CGG', seq)
			if pos:
				found += 1
				if getReverse:
					smallRNAs.append(revComp(pos.group(1)))
				else:
					smallRNAs.append(pos.group(1))
			else:
				notfound += 1
				nonfounds.append(seq)
	#print file + ':\ttrimmed:' + str(found) + ',cannot be trimmed:' + str(notfound) + ',% of data lost:' + str(100.0*notfound/(found+notfound))+ '\tread interval: [10-60]'
	return [smallRNAs, found, notfound]



#main function for trimming all adaptors in all files
def trimAdaptors(index2sample, minLen=10, maxLen=60):
	sample2counts = {index2sample[index]:[] for index in index2sample}
	sample2found = {index2sample[index]:0 for index in index2sample}
	sample2notFound = {index2sample[index]:0 for index in index2sample}
	files = os.listdir('./')
	index2files = {index:[] for index in index2sample.keys()}
	for index in index2sample:
		for file in files:
			if index in file:
				index2files[index].append(file)
	for index in index2files:
		print "Processing " + index
		for file in index2files[index]:
			print file
			smallRNAs, found, notFound = removeAdapter(file, minLen, maxLen)
			sample2counts[index2sample[index]] += smallRNAs
			sample2found[index2sample[index]] += found
			sample2notFound[index2sample[index]] += notFound
		print len(sample2counts[index2sample[index]])
	#try:		
	#	os.mkdir('./processed')
	sample2seqCounts = {}
	for sample in sample2counts:
		currCounts = Counter(sample2counts[sample]).most_common()
		sample2seqCounts[sample] = currCounts
		print sample + "\t" + str(len(currCounts))
		all = '\n'.join(['>' + seq + ':' + str(count) + '\n' + seq for seq, count in currCounts])
		with open('./processed/' + sample + '_rawCounts.fa', 'w') as f:
			f.write(all)
	return [sample2seqCounts, sample2found, sample2notFound]

