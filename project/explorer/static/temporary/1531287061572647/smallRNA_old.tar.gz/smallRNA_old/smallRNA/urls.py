from django.conf.urls import include, url
from django.contrib import admin
from basics import views as basicsViews
from pivot_tables import views as pivotViews

urlpatterns = [
    # Examples:
    # url(r'^$', 'smallRNA.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'login/$', basicsViews.login, name='login'),
	url(r'logout/$', basicsViews.logout, name='logout'),
    url(r'^$', basicsViews.startProcessing, name='startProcessing'),
    url(r'^basics/uploadFASTQ/$', basicsViews.uploadFASTQ, name='uploadFASTQ'),
    url(r'^basics/uploadRawCounts/$', basicsViews.uploadRawCounts , name='uploadRawCounts '),
    url(r'^basics/startProcessing/(?P<job_id>\w+)/(?P<session>[\w ]{0,50})$', basicsViews.startProcessing, name='startProcessing'),
    url(r'^basics/submittedJobs/$', basicsViews.startProcessing, name='startProcessing'),
    url(r'^basics/getJson/(?P<job_id>\w+)/(?P<file>.+)$', basicsViews.getJson, name='getJson'),
    url(r'^basics/showJobDetails/(?P<job_id>\w+)/$', basicsViews.showJobDetails, name='showJobDetails'),
    url(r'^pivot/listData/$', pivotViews.listData, name='listData'),
    url(r'^pivot/receiveRequest/$', pivotViews.receiveRequest, name='receiveRequest'),
    url(r'^pivot/getFile/(?P<prefix>[\w._]+)/$', pivotViews.getFile, name='getFile'),

]
