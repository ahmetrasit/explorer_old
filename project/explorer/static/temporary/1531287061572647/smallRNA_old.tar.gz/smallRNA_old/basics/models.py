from django.db import models

class Job(models.Model):
	job_id = models.CharField(max_length=50)
	session = models.CharField(max_length=50)
	username = models.CharField(max_length=50)
	status = models.CharField(max_length=50)
	last_change = models.CharField(max_length=50)
	parameters = models.CharField(max_length=1000)