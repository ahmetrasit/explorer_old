# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Job',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, verbose_name='ID', auto_created=True)),
                ('job_id', models.CharField(max_length=50)),
                ('session', models.CharField(max_length=50)),
                ('username', models.CharField(max_length=50)),
                ('status', models.CharField(max_length=50)),
                ('last_change', models.CharField(max_length=50)),
                ('parameters', models.CharField(max_length=1000)),
            ],
        ),
    ]
