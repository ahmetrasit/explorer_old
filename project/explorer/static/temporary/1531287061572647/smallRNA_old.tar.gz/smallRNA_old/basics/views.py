from django.shortcuts import render, render_to_response
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.http import JsonResponse

from basics.models import Job
from basics.forms import UploadFileForm

import os
import time
import subprocess
import re
import json

# Create your views here.
@login_required
def homepage(request):
	return render(request, 'homepage.html', {'user':request.user})


@login_required
def showJobDetails(request, job_id):
	json_files = getJsonFiles(request.user.username, job_id)
	session = getSessionName(request.user.username, job_id)
	return render(request, 'showJobDetails.html', {'user':request.user, 'job_id':job_id, 'json_files':json_files})


def getJson(request, job_id, file):
	response_data = ''
	path = './static/upload/' + request.user.username + '/' + job_id + '/' + file
	print(path)
	with open(path) as json_data:
		response_data = json.load(json_data)
	return JsonResponse(response_data, safe=False)


def getSessionName(username, job_id):
	path = './static/upload/'+username + '/' + job_id + '/'
	json_files = [curr for curr in os.listdir(path) if curr.split('.')[0] == 'smallRNAsession']
	print(json_files)
	return json_files[0].split('.')[1]


@login_required
@csrf_exempt
def uploadRawCounts (request):
	if request.method == 'POST':
		form = UploadFileForm(request.POST, request.FILES)
		if form.is_valid():
			for i in range(len(request.FILES.getlist('file'))):
				file = request.FILES.getlist('file')[i]
				filename = str(file)
				handle_uploaded_file(file, filename, request.user.username)
			session = re.sub(r"\W", "_", request.POST['session'])
			job_id = str(int(time.time()))
			addToRawCountsQueue(job_id, session, request.user.username, request.user.email)
			return HttpResponseRedirect('/basics/startProcessing/' + job_id + '/' + session)
	else:
		form = UploadFileForm()

	return render_to_response('upload.html', {'form': form, 'user':request.user, 'type':'raw_count', 'action':'uploadRawCounts'})

@login_required
@csrf_exempt
def uploadFASTQ(request):
	if request.method == 'POST':
		form = UploadFileForm(request.POST, request.FILES)
		if form.is_valid():
			for i in range(len(request.FILES.getlist('file'))):
				file = request.FILES.getlist('file')[i]
				filename = str(file)
				handle_uploaded_file(file, filename, request.user.username)
			session = re.sub(r"\W", "_", request.POST['session'])
			indexes = request.POST.getlist('indexSeq')
			sample_names = request.POST.getlist('sampleName')
			details = request.POST.getlist('details')
			adapter = request.POST.getlist('adapter')[0]
			print('adapter:' + adapter)
			job_id = str(int(time.time()))
			parameters = '_'
			type='plain'
			parameters = ','.join(indexes) + "|" + ','.join(sample_names) + "|" + ','.join(details) + "|" + adapter
			if len(indexes) > 0 :
				type = 'multiplex'
			addToQueue(job_id, session, request.user.username, request.user.email, type, parameters)
			return HttpResponseRedirect('/basics/startProcessing/' + job_id + '/' + session)
	else:
		form = UploadFileForm()

	return render_to_response('upload.html', {'form': form, 'user':request.user, 'type':'fastq', 'action':'uploadFASTQ'})

@csrf_exempt
def handle_uploaded_file(f, filename, username):
	try:
		 os.makedirs('static/upload/' + username)
		 os.makedirs('static/upload/' + username + '/' + 'csv')
		 os.makedirs('static/upload/' + username + '/' + 'userdata')
	except:
		pass
	with open('static/upload/' + username + '/'+ filename, 'wb+') as destination:
		for chunk in f.chunks():
			destination.write(chunk)

@login_required
def startProcessing(request, job_id='', session=''):
	if session:
		description = session
	else:
		description = job_id
	finished, pending = getJobList(request.user.username)
	return render(request, 'startProcessing.html', {'user':request.user, 'job_id':description, 'finished':finished, 'pending':pending})


def addToQueue(job_id, session, username, email, type, parameters):
	dir = 'static/upload/' + username
	files = [file for file in os.listdir(dir) if not os.path.isdir(os.path.join(dir, file)) and file[0]!= '.']
	print(files)
	if len(files)>0:
		job_id = str(int(time.time()))
		try:
			 os.makedirs(os.path.join(dir, job_id))
		except:
			pass
		for file in files:
			os.rename(os.path.join(dir,file), os.path.join(dir, job_id, file))

	job = Job(
				job_id = job_id,
				session = session,
				username = username,
				status = 'moved',
				last_change = job_id,
				parameters = parameters)
	job.save()
	print('python ./static/scripts/process.py ' + username + ' ' + email + ' '+ job_id + ' ' + type + ' ' + session + ' ' + parameters)
	subprocess.Popen('python ./static/scripts/process.py ' + username + ' ' + email + ' ' + job_id + ' ' + type + ' ' + session + ' "' + parameters+'"', shell=True)
	#print(subprocess.check_output('ls'))


def addToRawCountsQueue(job_id, session, username, email):
	dir = 'static/upload/' + username
	files = [file for file in os.listdir(dir) if not os.path.isdir(os.path.join(dir, file)) and file[0]!= '.']
	print(files)
	if len(files)>0:
		job_id = str(int(time.time()))
		try:
			 os.makedirs(os.path.join(dir, job_id))
		except:
			pass
		for file in files:
			os.rename(os.path.join(dir,file), os.path.join(dir, job_id, file))
	print('python ./static/scripts/rawCounts_process.py ' + username + ' ' + email + ' '+ job_id + ' ' + session)
	subprocess.Popen('python ./static/scripts/rawCounts_process.py ' + username + ' ' + email + ' ' + job_id + ' ' + session, shell=True)





def login(request):
	if request.user.is_authenticated():
		return render(request, 'login.html', {'user':request.user})
	else:
		if request.method == 'POST':
			username = request.POST['user']
			password = request.POST['pass']

			user = authenticate(username=username, password=password)
			if user:
				if user.is_active:
					auth_login(request, user)
					return HttpResponseRedirect('/')
				else:
					return HttpResponse("Account is not active, please contact us.")
			else:
				print("Wrong username or password; even the user does not exist")
				return HttpResponse("Wrong username or password; even the user does not exist")
	return render(request, 'login.html')

@login_required
def logout(request):
	auth_logout(request)
	return HttpResponseRedirect('/')


def getJobList(username):
	try:
		 os.makedirs('static/upload/' + username)
		 os.makedirs('static/upload/' + username + '/' + 'csv')
		 os.makedirs('static/upload/' + username + '/' + 'userdata')
	except:
		pass
	path = './static/upload/'+username + '/'
	finished = []
	pending = []
	dirs = [curr for curr in os.listdir(path) if os.path.isdir(path + curr)]
	for dir in dirs:
		if os.path.isfile(path+dir+'/'+'job_finished'):
			finished.append({'id':dir, 'session': getSessionName(username, dir)})
		else:
			if dir=='csv' or dir=='userdata':
				pass
			else:
				pending.append(dir)
	return finished, pending


def getJsonFiles(username, job_id):
	path = './static/upload/'+username + '/' + job_id + '/'
	json_files = [curr for curr in os.listdir(path) if curr.split('.')[-1] == 'json']
	return json_files
